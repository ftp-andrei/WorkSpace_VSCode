export class productCreate {

  name: string;

  desc: string;

  precio: number;

  constructor() {
    this.name = "";
    this.desc="";
    this.precio = 0;
  }
}
