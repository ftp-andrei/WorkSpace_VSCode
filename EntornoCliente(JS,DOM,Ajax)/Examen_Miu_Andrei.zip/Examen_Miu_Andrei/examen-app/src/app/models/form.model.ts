export interface FormModel {
  nombre: string;
  password: string;
}