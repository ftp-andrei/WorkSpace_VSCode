import { Component } from '@angular/core';

@Component({
  selector: 'app-productospage',
  templateUrl: './productospage.component.html',
  styleUrls: ['./productospage.component.css']
})
export class ProductospageComponent {

}
